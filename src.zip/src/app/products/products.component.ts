import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  products:any;
  cartProducts:any;

  constructor(private router: Router) { }

  ngOnInit() {
    let data=localStorage.getItem('cart');
    if(data!==null){
      this.cartProducts = JSON.parse(data);
    }
    else {
      this.cartProducts = [];
    }
    this.products = [
      {
        id:1,
        title:"Hells Kitchen",
        description:"Hells Kitchen",
        img:"assets/1.png",
        price:3 
      },
      {
        id:2,
        title:"Riley&Themad",
        description:"Riley&Themad",
        img:"assets/2.png",
        price:3 
      },
      {
        id:3,
        title:"Nesprasso",
        description:"Nesprasso",
        img:"assets/3.png",
        price:5
      },
      {
        id:4,
        title:"Vail Mountain",
        description:"Vail Mountain",
        img:"assets/4.png",
        price:3 
      },
     
      {
        id:5,
        title:"Invigo",
        description:"Invigo",
        img:"assets/5.png",
        price:10
      },
      {
        id:6,
        title:"Kopiko",
        description:"Kopiko",
        img:"assets/6.png",
        price:10
      },
      {
        id:7,
        title:"Ailleo",
        description:"Ailleo",
        img:"assets/7.png",
        price:13
      },
      {
        id:8,
        title:"Blendy",
        description:"Blendy",
        img:"assets/8.png",
        price:13
      },
      {
        id:9,
        title:"Stott's",
        description:"Stott's",
        img:"assets/9.png",
        price:13
      }
    ];
  }
  addToCart(index){
    let product=this.products[index];
    let cartData=[];
    let data = localStorage.getItem('cart');
    console.log("data :"+data);
    console.log("data type:"+typeof data);
    if(data!=="null")
    {
      cartData=JSON.parse(data);
    }
    cartData.push(product);
    this.updateCartData(cartData);
    localStorage.setItem('cart',JSON.stringify(cartData));
    this.products[index].isAdded=true;   
   }
   updateCartData(cartData){
     this.cartProducts=cartData;
   }
   goToCart(){
    this.router.navigate(['/cart']);
   }
}